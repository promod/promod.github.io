Promod LIVE V2.01 - README
http://www.modernwarfare.se/promod4/
2009-07-17 <promod4 [at] modernwarfare.se>

#promod4

Developers: Trivve & Ingram
Manager: abhi

Except various bug fixes and code-enhancements:

- Fully functional shoutcaster overlay for all resolutions and aspect ratios
- Class loadouts are preserved in the rank file
- Class related binds
- Enhanced client- and server-security
- Small changes/improvements to the hud and menus
- Players left-HUD is rebuilt and therefore possible to get rid of for those nice-looking frag-movies
- Full Hardcore-mode support, including support for all gametypes, HC mode will also use cook-nades
- Red enemy crosshair glitch through smoke fixed
- Added a strat mode (promod_mode strat) with nadetraining possibility, similar to AM4PAM
- Client-side scorebot functionality implemented, similar to the PAM4 ditto.
- Disabled ammo-sharing between SMG-class and M9 Beretta, as well as reduced weapon switch on M16
- All taunt sounds removed

FAQ:

Q: What about the hardcore, and support for all gametypes, how do I use them?
A: You should set promod_mode to "match(_hc)". For a complete list of promod modes, see below.

Q: Can the rulesets be customized to fit my needs?
A: Promod has always been about an unified ruleset. Therefore they only thing you can change in the regular match-modes is mr-rating (SD and SAB only).

Q: I want to run my own custom promod-server with skins etc, how?
A: In order to run your own custom promod-server you'll need to change the fs_game to "promodlive201_custom", and set promod_mode to "custom_public". You will now be able to modity the Promod IWDs and add additional (z_svr_*) files

Q: How can I disable the players left-HUD?
A: First of all, the demo must be recorded using Promod 4.42 or LIVE V2. Then set the command "hud_enable" to "0".

Q: Can I use this mod as a movie mod?
A: Yes, you can! Commands (which are important for movie-making) are only forced on the clients once connected (with one exception, see below). Demos needs to be loaded using devmap before starting a demo ("devmap mp_crash; disconnect").

Q: How do I get the scorebot running?
A: See below for scorebot dvars.

Q: Class related binds, how do they work?
A: See below for a list of commands.

Q: My question is not answered here.
A: Join #promod4 @ QuakeNet, or if You prefer Xfire, contact Trivve (trivia89) or Ingram (ingram93).

PROMOD MODES

mr-modes:

match_mr[x],
match_hc_mr[x],
lan_mr[x],
lan_hc_mr[x],
1v1_mr[x],
1v1_hc_mr[x],
2v2_mr[x],
2v2_hc_mr[x],
knockout_mr[x],
knockout_hc_mr[x],
knockout_lan_mr[x],
knockout_lan_hc_mr[x],
knockout_1v1_mr[x],
knockout_1v1_hc_mr[x]
knockout_2v2_mr[x],
knockout_2v2_hc_mr[x]

non-mr:

match
match_hc
comp_public,
custom_public,
strat

SCOREBOT

To enable scorebot, add this to your server config:

seta promod_enable_scorebot "1"
sets __promod_attack_score ""
sets __promod_defence_score ""
sets __promod_ticker ""
sets __promod_version ""
sets __promod_mode ""

FORCED COMMANDS

All these dvars are forced by Promod automatically, and make sure they stay untouched to avoid being punished!

aim_automelee_enabled 0
aim_automelee_range 0
dynent_active 0
snaps 30
cl_maxpackets 100
rate 25000
cg_nopredict 0
sm_enable 0
r_dlightLimit 0
r_lodscalerigid 1
r_lodscaleskinned 1
cg_drawcrosshairnames 0
cg_viewzsmoothingmin 1
cg_viewzsmoothingmax 16
cg_viewzsmoothingtime 0.1
cg_huddamageiconheight 64
cg_huddamageiconwidth 128
r_filmtweakInvert 0
r_zfeather 0
r_smc_enable 0
r_distortion 0
r_desaturation 0
r_specularcolorscale 0
fx_drawclouds 0 // is set every new round
r_fog 0

com_maxfps 40 - 250
compassplayerwidth EQUAL TO compassplayerheight
compassfriendlywidth EQUAL TO compassfriendlyheight

CLASS BINDS

You can bind them via the in-game menu. (Controls - Multiplayer Controls�)
Alternatively you can manually bind them in the console.

bind [KEY] [COMMAND]

openscriptmenu quickpromod silencer //toggles silencer on/off on the primary weapon
openscriptmenu quickpromod grenade //toggles between flash/smoke-grenade
openscriptmenu quickpromod assault
openscriptmenu quickpromod specops
openscriptmenu quickpromod demolitions
openscriptmenu quickpromod sniper

NOTES FOR SERVER-ADMINS

Do not rename any files and if possible please set fs_game to "mods/promodlive201". There's several reason why.
Some old PAM dvars are either removed or renamed to "promod_". Please refer to z_custom_ruleset.iwd for a complete list of dvars which are functional.