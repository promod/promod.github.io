CHANGELOG 4.41:

Bugfixes:

- Timeout issues fixed
- MP44 firerate fixed
- Fixed issue where auto-melee knife was enabled in rare cases
- Prevent using heavygunner (if you go directly to the menu using the console)

Feutures:

- Class related binds (toggle silencer, toggle special grenade, class loadouts)

You can bind them via the in-game menu. (Controls - Multiplayer Controls...)
Alternatively you can manualy bind them in the console.

bind [KEY] [COMMAND]

Commands:

openscriptmenu quickpromod silencer
openscriptmenu quickpromod grenade
openscriptmenu quickpromod assault
openscriptmenu quickpromod specops
openscriptmenu quickpromod demolitions
openscriptmenu quickpromod sniper

Changes/Improvements:

- Slight damage boost to all weapons, including bumped hand hitbox
- Death delay shortened
- Various menu tweaks
- Server security improved, promod will display a warning message if the promod441.iwd file is altered, or if any server-side only iwd-file(s) are loaded in server

fs_game must be set to "mods/promod441".


CHANGELOG 4.40:

compared to "beta final"

- All reported bugs is fixed, that's included shoutcaster overlay, hardpoints, ambient sounds and timeout issues
- Fixed some in-game-stats bugs
- Code optimizations for smoother gameplay
- All factional errors from Promod 3 fixed, thus resulting in different uniforms on some maps
- A global match-mode (promod_mode match and promod_mode match_hc, for hardcore matches) has been added for other purposes than S&D matches.
- Updated the custom ruleset (z_custom_ruleset.iwd)
- Removed all taunt, scream sounds (when you reload your weapon etc)
- You can no longer spectate the opposite team after a round is over (S&D)

WEAPONS:

- Aimbased hitboxes
- Stopping power has been reduced to 10% from 40%

MP5 has the same penetration power as the AK-74U, however, it's slightly weaker at close range but a little stronger
on mid/long range compared to the AK-74U.

Shotguns spreads the bullets a bit more to be actually good at close range.

M16 enormous fast weapon switch fixed.

A class loadout of a MP5 or UZI and a M9 Beretta as a secondary pistol will no longer share ammo.