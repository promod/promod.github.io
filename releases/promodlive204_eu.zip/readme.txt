Promod LIVE V2.04 EU - README
http://www.modernwarfare.se/promod4/
2009-07-28 <promod4 [at] modernwarfare.se>

#promod4

Developers: Trivve & Ingram
Manager: abhi

In this zip-package:

promodlive204\mod.ff
promodlive204\promodlive204.iwd
promodlive204\z_custom_ruleset.iwd
readme.txt
server.cfg
server_setup.txt

CHANGES

LIVE V2.04:

- Reintroduced "cl_maxpackets" enforcement to "100"
- Small fix in the scorebot
- Weapon class availability fixed on halftime

LIVE V2.03:

After one hotfix and several release candidates:

- Added delay in the end of the round for movie-makers
- Several minor bugs fixed
- Prevention for "spec-nading"
- Updated promod modes
- Forcing for maxpackets (100) removed, it's now possible to use 60 - 100 (some regions need this, if leagues need fixed values, use punkbuster scripts to force)
- Team auto-balancing has been removed, which was causing severe issues, for instance HUD-disappearing and invariability bug
- The in-game stats has been removed, due to big inaccuracies in values

Big thanks to the community for reporting bugs and other issues.
Especially thanks to paradox-, and other that we might forgot. Also thanks to giunuz and SirXenos for extensive bug testing.

LIVE V2:

Except various bug fixes and code-enhancements:

- Fully functional shoutcaster overlay for all resolutions and aspect ratios
- Class loadouts are preserved in the rank file
- Class related binds
- Enhanced client- and server-security
- Small changes/improvements to the hud and menus
- Players left-HUD is rebuilt and therefore possible to get rid of for those nice-looking frag-movies
- Full Hardcore-mode support, including support for all gametypes, HC mode will also use cook-nades
- Red enemy crosshair glitch through smoke fixed
- Added a strat mode (promod_mode strat) with nadetraining possibility, similar to AM4PAM
- Client-side scorebot functionality implemented, similar to the PAM4 ditto.
- Disabled ammo-sharing between SMG-class and M9 Beretta, as well as reduced weapon switch on M16
- All taunt sounds removed

FAQ

Q: What about the hardcore, and support for all gametypes, how do I use them?
A: For a complete list of promod modes, see below.

Q: Can the rulesets be customized to fit my needs?
A: Promod has always been about an unified ruleset. Therefore they only thing you can change in the regular match-modes is mr-rating (SD and SAB only).

Q: I want to run my own custom promod-server with skins etc, how?
A: In order to run your own custom promod-server you'll need to change the fs_game to include "custom" e.g "sniper_custom", and set promod_mode to "custom_public". You will now be able to modify the Promod IWDs and add additional (z_svr_*) files.

Q: How can I disable the players left-HUD?
A: First of all, the demo must have been recorded using Promod 4.42 or LIVE V2. Then set the command "hud_enable" to "0".

Q: Can I use this mod as a movie mod?
A: Yes, you can! Commands (which are important for movie-making) are only forced on the clients once connected (with one exception, see below). Demos needs to be loaded using devmap before starting a demo ("devmap mp_crash;disconnect"). If you only having black screen, change r_contrast to "1" as well as r_brightness to "0".

Q: How do I get the scorebot running?
A: See below for scorebot dvars.

Q: Class related binds, how do they work?
A: See below for a list of commands.

Q: My question is not answered here.
A: Join #promod4 @ QuakeNet, or if You prefer Xfire, contact Trivve (trivia89) or Ingram (ingram93).

PROMOD MODES

mr-modes (for SD and SAB only):

match_mr[x]
match_hc_mr[x]
lan_mr[x]
lan_hc_mr[x]
1v1_mr[x]
1v1_hc_mr[x]
2v2_mr[x]
2v2_hc_mr[x]
knockout_mr[x]
knockout_hc_mr[x]
knockout_lan_mr[x]
knockout_lan_hc_mr[x]
knockout_1v1_mr[x]
knockout_1v1_hc_mr[x]
knockout_2v2_mr[x]
knockout_2v2_hc_mr[x]

non-mr:

match
match_hc
lan
lan_hc
comp_public
comp_public_hc
custom_public
strat

SCOREBOT

To enable scorebot, add this to your server config:

seta promod_enable_scorebot "1"
sets __promod_attack_score ""
sets __promod_defence_score ""
sets __promod_ticker ""
sets __promod_version ""
sets __promod_mode ""

FORCED COMMANDS

All these dvars are forced by Promod automatically, and make sure they stay untouched to avoid being punished!

aim_automelee_enabled 0
aim_automelee_range 0
dynent_active 0
snaps 30
rate 25000
cg_nopredict 0
sm_enable 0
r_dlightLimit 0
r_lodscalerigid 1
r_lodscaleskinned 1
cg_drawcrosshairnames 0
cg_viewzsmoothingmin 1
cg_viewzsmoothingmax 16
cg_viewzsmoothingtime 0.1
cg_huddamageiconheight 64
cg_huddamageiconwidth 128
r_filmtweakInvert 0
r_zfeather 0
r_smc_enable 0
r_distortion 0
r_desaturation 0
r_specularcolorscale 0
fx_drawclouds 0 // is set every new round
r_fog 0

com_maxfps 40 - 250
cl_maxpackets 60 - 100
compassplayerwidth EQUAL TO compassplayerheight
compassfriendlywidth EQUAL TO compassfriendlyheight

CLASS BINDS

You can bind them via the in-game menu. (Controls - Multiplayer Controls�)
Alternatively you can manually bind them in the console/config.

bind [KEY] [COMMAND]

openscriptmenu quickpromod silencer //toggles silencer on/off on the primary weapon
openscriptmenu quickpromod grenade //toggles between flash/smoke-grenade
openscriptmenu quickpromod assault
openscriptmenu quickpromod specops
openscriptmenu quickpromod demolitions
openscriptmenu quickpromod sniper

NOTES FOR SERVER-ADMINS AND SERVER HOSTING COMPANIES

To avoid any possible issues and if possible, please use fs_game "mods/promodlive204".
If your server host doesn't allow you to change fs_game manually, please use "mods/promodlive2" or anything else what is available. It's not restricted.
Do not rename any files or modify contents of them.
Some old PAM dvars are either removed or renamed to "promod_*".
Please refer to z_custom_ruleset.iwd for a complete list of dvars which are functional.