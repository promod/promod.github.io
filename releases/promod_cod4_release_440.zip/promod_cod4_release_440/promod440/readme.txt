PROMOD 4.40:

After almost 4 months of coding on Promod 4 the last* version is here. This release wouldn't been possible if it wasn't for, bullet-worm, the original
PAM4 creator (which Promod is built on), raf1 the original Promod developer, Trivve, Carlisle and with all community feedback.

CHANGELOG:

compared to "beta final"

- All reported bugs is fixed, that's included shoutcaster overlay, hardpoints,
  ambient sounds and timeout issues.
- Fixed some in-game-stats bugs.
- Code optimizations for smoother gameplay.
- All factional errors from Promod 3 fixed, thus resulting in different uniforms on some maps, sorry.
- A global match-mode (promod_mode match and promod_mode match_hc for hardcore matches) has been added for other purposes than S&D matches.
- Updated the custom ruleset (z_custom_ruleset.iwd)
- Removed all taunt sounds (when you reload your weapon etc)
- You can no longer spectate the opposite team after a round is over (S&D)

WEAPONS:

- Aimbased hitboxes
- Stopping power has been reduced to 15% from 40%

MP5 has the same penetration power as the AK-74U, however, it's slightly weaker at close range but a little stronger
on mid/long range compared to the AK-74U.

Shotguns spreads the bullets a bit more to be actually good at close range.

M16 enormous fast weapon switch fixed.

A class loadout of a MP5 or UZI and a M9 Beretta as a secondary pistol will no longer give You double amount of ammo (stock bug).

Do not rename any files in this package to avoid server violations. You are not allowed to run this version with modified server IWD-files.
fs_game must be set to "mods/promod440" in the server config/commandline.

Thanks to all the people that have helped me testing and giving me feedback.
Special thanks to Rolgen, abhi, Ingram, Carlisle and team Unitis.